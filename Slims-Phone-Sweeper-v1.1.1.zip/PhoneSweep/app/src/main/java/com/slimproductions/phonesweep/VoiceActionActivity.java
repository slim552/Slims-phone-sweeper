package com.slimproductions.phonesweep;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class VoiceActionActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        dispatch(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        dispatch(intent);
    }

    private void dispatch(Intent incoming) {
        Class<?> target = MainActivity.class;
        boolean autoRunOptimize = false;
        String action = incoming == null ? null : incoming.getAction();
        Uri data = incoming == null ? null : incoming.getData();

        if ("com.slimproductions.phonesweep.SCAN_DUPLICATES".equals(action)) {
            target = DuplicateScanActivity.class;
        } else if ("com.slimproductions.phonesweep.SCAN_SIMILAR".equals(action)) {
            target = SimilarPhotoActivity.class;
        } else if ("com.slimproductions.phonesweep.SCAN_LARGE_FILES".equals(action)) {
            target = LargeFilesActivity.class;
        } else if ("com.slimproductions.phonesweep.ORGANIZE".equals(action)) {
            target = OrganizerActivity.class;
        } else if ("com.slimproductions.phonesweep.DEEP_CLEAN".equals(action)) {
            target = FullCleanActivity.class;
        } else if ("com.slimproductions.phonesweep.OPTIMIZE".equals(action)) {
            target = OptimizeActivity.class;
            autoRunOptimize = true;
        } else if (data != null) {
            String host = data.getHost() == null ? "" : data.getHost();
            String path = data.getPath() == null ? "" : data.getPath();
            if ("scan".equals(host) && path.contains("duplicates")) target = DuplicateScanActivity.class;
            else if ("scan".equals(host) && path.contains("similar")) target = SimilarPhotoActivity.class;
            else if ("scan".equals(host) && path.contains("large")) target = LargeFilesActivity.class;
            else if ("organize".equals(host)) target = OrganizerActivity.class;
            else if ("clean".equals(host)) target = FullCleanActivity.class;
            else if ("optimize".equals(host)) {
                target = OptimizeActivity.class;
                autoRunOptimize = true;
            }
        }
        Intent launch = new Intent(this, target);
        if (autoRunOptimize) launch.putExtra("auto_run", true);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(launch);
        finish();
    }
}
