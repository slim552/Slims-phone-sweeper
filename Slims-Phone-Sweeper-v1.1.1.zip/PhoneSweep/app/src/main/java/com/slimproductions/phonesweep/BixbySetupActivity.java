package com.slimproductions.phonesweep;

import android.content.pm.ShortcutInfo;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.ShortcutManager;
import android.graphics.drawable.Icon;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class BixbySetupActivity extends BaseActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        root.addView(Ui.title(this, "Bixby & voice access"));
        root.addView(Ui.subtitle(this, "Slims Phone Sweeper includes launcher shortcuts and voice-safe deep links. Start with: “Hi Bixby, open Slims Phone Sweeper.” For one-sentence actions, create a Bixby Quick Command that opens one of the pinned shortcuts below."));

        LinearLayout examples = Ui.card(this);
        examples.addView(Ui.section(this, "Suggested commands"));
        examples.addView(Ui.body(this,
                "• Open Slims Phone Sweeper\n" +
                "• Open Scan duplicates\n" +
                "• Open Similar photos\n" +
                "• Open Find large files\n" +
                "• Open Smart organizer\n" +
                "• Open Deep clean\n" +
                "• Open Quick optimize\n\n" +
                "Depending on your Bixby version, the exact wording may vary. Pinned shortcuts give Bixby and the launcher a direct target."));
        root.addView(examples);

        Button duplicates = Ui.button(this, "Pin Duplicate Scan shortcut");
        duplicates.setOnClickListener(v -> pin("duplicates_pin", "Scan duplicates", "phonesweep://scan/duplicates"));
        root.addView(duplicates);
        Button similar = Ui.secondaryButton(this, "Pin Similar Photos shortcut");
        similar.setOnClickListener(v -> pin("similar_pin", "Similar photos", "phonesweep://scan/similar"));
        root.addView(similar);
        Button large = Ui.secondaryButton(this, "Pin Large Files shortcut");
        large.setOnClickListener(v -> pin("large_pin", "Find large files", "phonesweep://scan/large"));
        root.addView(large);
        Button organize = Ui.secondaryButton(this, "Pin Smart Organizer shortcut");
        organize.setOnClickListener(v -> pin("organize_pin", "Smart organizer", "phonesweep://organize/run"));
        root.addView(organize);
        Button clean = Ui.secondaryButton(this, "Pin Deep Clean shortcut");
        clean.setOnClickListener(v -> pin("clean_pin", "Deep clean", "phonesweep://clean/run"));
        root.addView(clean);
        Button optimize = Ui.secondaryButton(this, "Pin Quick Optimize shortcut");
        optimize.setOnClickListener(v -> pin("optimize_pin", "Quick optimize", "phonesweep://optimize/run"));
        root.addView(optimize);

        Button copy = Ui.secondaryButton(this, "Copy Bixby setup instructions");
        copy.setOnClickListener(v -> {
            String text = "In Bixby, create a Quick Command. Use a phrase like ‘clean my phone’. Add the action ‘Open Quick optimize’ or ‘Open Smart organizer’ or ‘Open Slims Phone Sweeper’. Slims Phone Sweeper actions can also be launched with phonesweep://scan/duplicates, phonesweep://scan/similar, phonesweep://scan/large, phonesweep://organize/run, phonesweep://clean/run, and phonesweep://optimize/run.";
            ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            manager.setPrimaryClip(ClipData.newPlainText("Slims Phone Sweeper Bixby setup", text));
            Toast.makeText(this, "Instructions copied", Toast.LENGTH_SHORT).show();
        });
        root.addView(copy);

        setContentView(Ui.scrollScreen(this, root));
    }

    private void pin(String id, String label, String uri) {
        if (Build.VERSION.SDK_INT < 26) {
            Toast.makeText(this, "Pinned shortcuts require Android 8 or newer", Toast.LENGTH_LONG).show();
            return;
        }
        ShortcutManager manager = getSystemService(ShortcutManager.class);
        if (manager == null || !manager.isRequestPinShortcutSupported()) {
            Toast.makeText(this, "Your launcher does not support pinning this shortcut", Toast.LENGTH_LONG).show();
            return;
        }
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri), this, VoiceActionActivity.class);
        ShortcutInfo info = new ShortcutInfo.Builder(this, id)
                .setShortLabel(label)
                .setLongLabel(label + " in Slims Phone Sweeper")
                .setIcon(Icon.createWithResource(this, R.mipmap.ic_launcher))
                .setIntent(intent)
                .build();
        manager.requestPinShortcut(info, null);
    }
}
