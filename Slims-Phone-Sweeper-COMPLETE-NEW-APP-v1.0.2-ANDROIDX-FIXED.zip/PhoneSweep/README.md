# Slims Phone Sweeper 1.0.1 Complete New App

Slims Phone Sweeper is a private Android storage cleaner and smart media organizer built for a Samsung Galaxy S21 and other Android 10+ phones.

## Cleanup tools

- Exact duplicate photo, video and audio detection with SHA-256 verification
- Similar-photo comparison
- Large-file review
- Download and public-storage cleanup previews
- Samsung Device Care, battery, storage and app-settings shortcuts
- Android trash/write approval before protected media changes

## Smart organizer

- Photos: offline image labels plus custom rules, then folders such as Kids & Family, Christmas, Puppy & Pets, Screenshots, Documents, People, Food, Vehicles, Events, Nature and Art
- Videos: analyzes the Android-generated video thumbnail and uses the same visual folders
- Music: folders for Albums, Singles, Stems, Instrumentals, Masters, Demos & Drafts and Recordings
- Downloads: folders for PDFs, Documents, Spreadsheets, Presentations, Archives, APK installers, Images, Audio, Videos, Web & Data and Other Files
- Custom rules use the format `Folder name=keyword,keyword`
- Every proposed move appears in a preview before anything is changed

The bundled ML Kit image-labeling model runs on the phone. Slims Phone Sweeper declares no internet permission and includes no advertising, account system, analytics or tracking.

## Important limits

Image labels are useful but not perfect. Generic image labeling can often recognize a child, dog, Christmas object, food, vehicle or document, but it cannot reliably identify a specific person such as a particular child. Always review the preview.

Android protects other apps' private data and system caches. Slims Phone Sweeper organizes shared media and, when the user grants optional all-files access, the public Downloads folder. It does not bypass Android security.

## Build

The included GitHub Actions workflow builds `app-debug.apk` using Java 17, Android SDK 35 and Gradle 8.9.


## Email cleaner & organizer

Version 1.2 adds safe Gmail cleanup shortcuts for important/starred mail, promotions, social notifications, newsletters, large attachments, old mail, spam and trash. It never stores an email password and never deletes automatically.
