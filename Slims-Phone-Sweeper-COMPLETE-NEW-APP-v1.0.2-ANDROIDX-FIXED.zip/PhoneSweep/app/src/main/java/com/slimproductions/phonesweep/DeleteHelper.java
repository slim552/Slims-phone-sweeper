package com.slimproductions.phonesweep;

import android.app.Activity;
import android.app.PendingIntent;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public final class DeleteHelper {
    public static final int REQUEST_TRASH = 5101;
    public static final int REQUEST_DELETE = 5102;
    public static final int REQUEST_WRITE = 5103;

    private DeleteHelper() {}

    public static void moveToTrash(Activity activity, List<Uri> uris) {
        if (uris == null || uris.isEmpty()) {
            Toast.makeText(activity, "Select at least one item", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            if (Build.VERSION.SDK_INT >= 30) {
                PendingIntent pending = MediaStore.createTrashRequest(
                        activity.getContentResolver(), new ArrayList<>(uris), true);
                activity.startIntentSenderForResult(pending.getIntentSender(), REQUEST_TRASH,
                        null, 0, 0, 0);
            } else {
                for (Uri uri : uris) activity.getContentResolver().delete(uri, null, null);
                Toast.makeText(activity, "Selected items deleted", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(activity, "Android blocked the request: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public static void requestWrite(Activity activity, List<Uri> uris) {
        if (Build.VERSION.SDK_INT < 30) return;
        try {
            PendingIntent pending = MediaStore.createWriteRequest(
                    activity.getContentResolver(), new ArrayList<>(uris));
            activity.startIntentSenderForResult(pending.getIntentSender(), REQUEST_WRITE,
                    null, 0, 0, 0);
        } catch (Exception e) {
            Toast.makeText(activity, "Could not request file access", Toast.LENGTH_LONG).show();
        }
    }
}
