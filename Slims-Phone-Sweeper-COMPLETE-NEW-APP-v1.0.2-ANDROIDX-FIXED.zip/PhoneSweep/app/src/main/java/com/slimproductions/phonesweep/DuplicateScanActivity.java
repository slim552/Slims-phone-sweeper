package com.slimproductions.phonesweep;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DuplicateScanActivity extends ReviewActivityBase {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setup("Exact duplicates", "Find byte-for-byte duplicate photos, videos and music. Slims Phone Sweeper hashes only files that share the same size, which makes the scan faster and avoids false matches.", "Move selected copies to trash");
        Button scan = Ui.button(this, "Start duplicate scan");
        scan.setOnClickListener(v -> runScan());
        root.addView(scan, 4);
        runScan();
    }

    private void runScan() {
        if (!PermissionHelper.hasMediaPermissions(this)) {
            status.setText("Media permission is required before scanning.");
            PermissionHelper.requestMediaPermissions(this);
            return;
        }
        results.removeAllViews();
        primaryAction.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        status.setText("Reading your media library…");
        executor.submit(() -> {
            List<MediaItem> all = new ArrayList<>();
            all.addAll(ScanUtils.queryImages(this));
            all.addAll(ScanUtils.queryVideos(this));
            all.addAll(ScanUtils.queryAudio(this));
            List<List<MediaItem>> groups = ScanUtils.findExactDuplicates(this, all,
                    (done, total, message) -> showProgress(done, total, message));
            showGroups(groups, true, "No exact duplicate photos, videos or music were found.");
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQUEST_MEDIA) {
            if (PermissionHelper.hasMediaPermissions(this)) runScan();
            else status.setText("Media access was not granted. You can grant it from Android app settings.");
        }
    }

    @Override
    protected void rerunAfterDelete() {
        runScan();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
