package com.slimproductions.phonesweep;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends BaseActivity {
    private TextView permissionStatus;
    private TextView storageStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);

        LinearLayout hero = Ui.card(this);
        hero.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.mipmap.ic_launcher);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(Ui.dp(this, 92), Ui.dp(this, 92));
        logo.setLayoutParams(logoParams);
        hero.addView(logo);
        TextView name = Ui.title(this, "Slims Phone Sweeper");
        name.setGravity(Gravity.CENTER);
        hero.addView(name);
        TextView tagline = Ui.subtitle(this, "Private cleanup and smart sorting for photos, videos, music, downloads, storage and email");
        tagline.setGravity(Gravity.CENTER);
        hero.addView(tagline);
        root.addView(hero);

        LinearLayout storageCard = Ui.card(this);
        storageCard.addView(Ui.section(this, "Storage overview"));
        storageStatus = Ui.body(this, storageSummary());
        storageCard.addView(storageStatus);
        permissionStatus = Ui.body(this, permissionSummary());
        permissionStatus.setPadding(0, Ui.dp(this, 8), 0, 0);
        storageCard.addView(permissionStatus);
        Button mediaAccess = Ui.button(this, "Grant photo, video and music access");
        mediaAccess.setOnClickListener(v -> PermissionHelper.requestMediaPermissions(this));
        storageCard.addView(mediaAccess);
        Button fullAccess = Ui.secondaryButton(this, "Optional: grant full file access");
        fullAccess.setOnClickListener(v -> PermissionHelper.requestAllFilesAccess(this));
        storageCard.addView(fullAccess);
        root.addView(storageCard);

        root.addView(Ui.section(this, "Smart cleanup"));
        root.addView(actionCard("Exact duplicates", "Byte-for-byte duplicate photos, videos and music with SHA-256 verification.",
                "Scan duplicates", DuplicateScanActivity.class));
        root.addView(actionCard("Similar photos", "Find burst shots, resized copies and near-identical pictures using a visual fingerprint.",
                "Compare photos", SimilarPhotoActivity.class));
        root.addView(actionCard("Large files", "Review your biggest accessible files before moving anything to Android trash.",
                "Find large files", LargeFilesActivity.class));
        root.addView(actionCard("Smart organize everything", "Use private on-device AI and custom rules to sort photos and videos into folders such as Kids & Family, Christmas and Puppy & Pets; sort music into albums, stems, instrumentals, masters and demos; and organize Downloads by file type.",
                "Open smart organizer", OrganizerActivity.class));
        root.addView(actionCard("Deep clean public storage", "Review old installers, incomplete downloads, temporary leftovers, thumbnail cache and empty folders.",
                "Start deep clean", FullCleanActivity.class));
        root.addView(actionCard("Email cleaner & organizer", "Safely review Gmail promotions, social mail, newsletters, large attachments and old unprotected messages while protecting important and starred mail.",
                "Open email cleaner", EmailCleanerActivity.class));
        root.addView(actionCard("Quick optimize", "Clear Slims Phone Sweeper cache and open Samsung Device Care, storage, apps and battery settings.",
                "Optimize safely", OptimizeActivity.class));
        root.addView(actionCard("Bixby and voice shortcuts", "Pin actions so Bixby, the launcher and automation tools can open specific Slims Phone Sweeper screens.",
                "Set up Bixby", BixbySetupActivity.class));

        LinearLayout privacy = Ui.card(this);
        privacy.addView(Ui.section(this, "Built for privacy"));
        privacy.addView(Ui.body(this,
                "• No internet permission used inside the app\n" +
                "• Smart image labels run on your phone\n" +
                "• No email password, ads or tracking\n" +
                "• Exact duplicates use cryptographic hashes\n" +
                "• Media deletions go through Android's confirmation and trash\n" +
                "• Deep-clean permanent deletion always asks again"));
        root.addView(privacy);

        setContentView(Ui.scrollScreen(this, root));
    }

    private LinearLayout actionCard(String title, String description, String buttonText, Class<?> target) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.section(this, title));
        card.addView(Ui.body(this, description));
        Button button = Ui.button(this, buttonText);
        button.setOnClickListener(v -> startActivity(new Intent(this, target)));
        card.addView(button);
        return card;
    }

    private String storageSummary() {
        try {
            StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getAbsolutePath());
            long total = stat.getTotalBytes();
            long free = stat.getAvailableBytes();
            long used = Math.max(0, total - free);
            int percent = total <= 0 ? 0 : Math.round(used * 100f / total);
            return "Used: " + Formatters.bytes(used) + " of " + Formatters.bytes(total)
                    + " (" + percent + "%)\nFree: " + Formatters.bytes(free);
        } catch (Exception e) {
            return "Storage totals will appear after Android makes them available.";
        }
    }

    private String permissionSummary() {
        String media = PermissionHelper.hasMediaPermissions(this) ? "Media access: enabled" : "Media access: needed";
        String files = PermissionHelper.hasAllFilesAccess() ? "Full file access: enabled" : "Full file access: optional";
        return media + "\n" + files;
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (permissionStatus != null) permissionStatus.setText(permissionSummary());
        if (storageStatus != null) storageStatus.setText(storageSummary());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQUEST_MEDIA) {
            permissionStatus.setText(permissionSummary());
            Toast.makeText(this, PermissionHelper.hasMediaPermissions(this)
                    ? "Media access enabled" : "Some media access was not granted", Toast.LENGTH_LONG).show();
        }
    }
}
