package com.slimproductions.phonesweep;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class EmailCleanerActivity extends BaseActivity {
    private static final String IMPORTANT = "is:important OR is:starred";
    private static final String PROMOTIONS = "category:promotions older_than:30d -is:important -is:starred";
    private static final String SOCIAL = "category:social older_than:30d -is:important -is:starred";
    private static final String NEWSLETTERS = "unsubscribe older_than:60d -is:important -is:starred";
    private static final String LARGE = "larger:10M older_than:90d -is:important -is:starred";
    private static final String OLD = "older_than:1y -is:important -is:starred -in:sent";
    private static final String RECORDS = "subject:(receipt invoice order confirmation statement court legal medical appointment bank tax insurance)";
    private static final String SPAM = "in:spam";
    private static final String TRASH = "in:trash";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        root.addView(Ui.title(this, "Email cleaner & organizer"));
        root.addView(Ui.subtitle(this,
                "Safe Gmail cleanup using Gmail's own importance markers and search filters. Nothing is deleted automatically. Each button opens a review list in Gmail so you stay in control."));

        LinearLayout safety = Ui.card(this);
        safety.addView(Ui.section(this, "Protect important mail first"));
        safety.addView(Ui.body(this,
                "Review starred and important messages before cleaning. Keep court, medical, banking, tax, insurance, receipts, family and work messages. Phone Sweeper never sees your password or reads email in the background."));
        safety.addView(searchButton("Review important & starred", IMPORTANT, true));
        safety.addView(searchButton("Review receipts and important records", RECORDS, false));
        root.addView(safety);

        root.addView(Ui.section(this, "Likely low-priority mail"));
        root.addView(searchCard("Old promotions", "Promotional mail older than 30 days, excluding messages Gmail marked important or starred.", PROMOTIONS));
        root.addView(searchCard("Old social notifications", "Social-network messages older than 30 days, excluding important and starred messages.", SOCIAL));
        root.addView(searchCard("Newsletters and mailing lists", "Messages containing unsubscribe links that are older than 60 days, excluding important and starred messages.", NEWSLETTERS));
        root.addView(searchCard("Large old attachments", "Messages larger than 10 MB and older than 90 days, excluding important and starred messages.", LARGE));
        root.addView(searchCard("Old unprotected mail", "Mail older than one year, excluding starred, important and sent mail. Review this carefully before deleting.", OLD));

        LinearLayout system = Ui.card(this);
        system.addView(Ui.section(this, "Spam and trash"));
        system.addView(Ui.body(this,
                "Open Gmail's Spam or Trash lists. Gmail controls final deletion and recovery windows."));
        system.addView(searchButton("Open Spam", SPAM, false));
        system.addView(searchButton("Open Trash", TRASH, false));
        root.addView(system);

        LinearLayout tools = Ui.card(this);
        tools.addView(Ui.section(this, "Cleanup tools"));
        tools.addView(Ui.body(this,
                "Inside Gmail, select only the messages you recognize as unwanted. Archive when unsure; delete only after reviewing the sender and subject."));
        Button openGmail = Ui.button(this, "Open Gmail inbox");
        openGmail.setOnClickListener(v -> openGmailSearch("in:inbox"));
        tools.addView(openGmail);
        Button copy = Ui.secondaryButton(this, "Copy all cleanup searches");
        copy.setOnClickListener(v -> copyQueries());
        tools.addView(copy);
        root.addView(tools);

        LinearLayout limits = Ui.card(this);
        limits.addView(Ui.section(this, "Why it does not auto-delete"));
        limits.addView(Ui.body(this,
                "No classifier can guarantee that every legal notice, receipt, family message or account warning is correctly identified. This version uses Gmail's existing categories and importance signals, then requires your review before any action."));
        root.addView(limits);

        setContentView(Ui.scrollScreen(this, root));
    }

    private LinearLayout searchCard(String title, String description, String query) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.section(this, title));
        card.addView(Ui.body(this, description));
        card.addView(searchButton("Review in Gmail", query, false));
        return card;
    }

    private Button searchButton(String label, String query, boolean primary) {
        Button button = primary ? Ui.button(this, label) : Ui.secondaryButton(this, label);
        button.setOnClickListener(v -> openGmailSearch(query));
        return button;
    }

    private void openGmailSearch(String query) {
        try {
            String encoded = Uri.encode(query);
            Uri url = Uri.parse("https://mail.google.com/mail/u/0/#search/" + encoded);
            Intent intent = new Intent(Intent.ACTION_VIEW, url);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open Gmail. Install Gmail or open mail.google.com in Chrome.", Toast.LENGTH_LONG).show();
        }
    }

    private void copyQueries() {
        String text =
                "IMPORTANT OR STARRED\n" + IMPORTANT + "\n\n" +
                "RECEIPTS AND RECORDS\n" + RECORDS + "\n\n" +
                "OLD PROMOTIONS\n" + PROMOTIONS + "\n\n" +
                "OLD SOCIAL\n" + SOCIAL + "\n\n" +
                "NEWSLETTERS\n" + NEWSLETTERS + "\n\n" +
                "LARGE OLD ATTACHMENTS\n" + LARGE + "\n\n" +
                "OLD UNPROTECTED MAIL\n" + OLD;
        ClipboardManager manager = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
        manager.setPrimaryClip(ClipData.newPlainText("Slims Phone Sweeper email cleanup searches", text));
        Toast.makeText(this, "Email cleanup searches copied", Toast.LENGTH_SHORT).show();
    }
}
