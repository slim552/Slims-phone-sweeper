package com.slimproductions.phonesweep;

import android.app.AlertDialog;
import android.graphics.Color;
import android.media.MediaScannerConnection;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class FullCleanActivity extends BaseActivity {
    private LinearLayout root;
    private LinearLayout results;
    private TextView status;
    private ProgressBar progress;
    private Button delete;
    private final Map<CheckBox, FileCandidate> selections = new LinkedHashMap<>();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        root = Ui.screen(this);
        root.addView(Ui.title(this, "Deep clean"));
        root.addView(Ui.subtitle(this, "Scan public storage for abandoned downloads, old installers, incomplete downloads, zero-byte leftovers and empty folders. Protected Android app folders are intentionally excluded."));
        status = Ui.body(this, PermissionHelper.hasAllFilesAccess()
                ? "Full file access is enabled."
                : "Optional full file access is required for this deeper scan.");
        root.addView(status);
        progress = Ui.progress(this);
        root.addView(progress);

        Button access = Ui.secondaryButton(this, "Grant full file access");
        access.setOnClickListener(v -> PermissionHelper.requestAllFilesAccess(this));
        root.addView(access);
        Button scan = Ui.button(this, "Scan safe public folders");
        scan.setOnClickListener(v -> runScan());
        root.addView(scan);

        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);

        delete = Ui.button(this, "Permanently delete selected files");
        delete.setVisibility(View.GONE);
        delete.setOnClickListener(v -> confirmDelete());
        root.addView(delete);
        setContentView(Ui.scrollScreen(this, root));
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (status != null && PermissionHelper.hasAllFilesAccess()) {
            status.setText("Full file access is enabled. Ready to scan.");
        }
    }

    private void runScan() {
        if (!PermissionHelper.hasAllFilesAccess()) {
            status.setText("Grant full file access first. Android opens a system settings page for this permission.");
            PermissionHelper.requestAllFilesAccess(this);
            return;
        }
        selections.clear();
        results.removeAllViews();
        delete.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        status.setText("Scanning public folders…");
        executor.submit(() -> {
            List<FileCandidate> candidates = scanPublicFolders();
            runOnUiThread(() -> showCandidates(candidates));
        });
    }

    private List<FileCandidate> scanPublicFolders() {
        List<FileCandidate> output = new ArrayList<>();
        List<File> roots = Arrays.asList(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC),
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        );
        long now = System.currentTimeMillis();
        int visited = 0;
        for (File rootFolder : roots) {
            if (rootFolder == null || !rootFolder.exists()) continue;
            Deque<File> stack = new ArrayDeque<>();
            stack.push(rootFolder);
            while (!stack.isEmpty() && visited < 150_000) {
                File file = stack.pop();
                visited++;
                if (file.isDirectory()) {
                    File[] children = file.listFiles();
                    if (children == null) continue;
                    if (children.length == 0 && !file.equals(rootFolder)) {
                        output.add(new FileCandidate(file, "Empty folder", true));
                    } else {
                        for (File child : children) stack.push(child);
                    }
                } else {
                    String name = file.getName().toLowerCase(Locale.US);
                    long ageDays = Math.max(0, (now - file.lastModified()) / 86_400_000L);
                    if (name.endsWith(".crdownload") || name.endsWith(".part") || name.endsWith(".download")
                            || name.endsWith(".tmp") || name.endsWith(".temp")) {
                        if (ageDays >= 2) output.add(new FileCandidate(file, "Incomplete or temporary download • " + ageDays + " days old", true));
                    } else if (file.length() == 0 && ageDays >= 7) {
                        output.add(new FileCandidate(file, "Zero-byte leftover • " + ageDays + " days old", true));
                    } else if (name.endsWith(".apk") && ageDays >= 30) {
                        output.add(new FileCandidate(file, "Old app installer • " + ageDays + " days old", false));
                    } else if ((name.endsWith(".zip") || name.endsWith(".rar") || name.endsWith(".7z")) && ageDays >= 90) {
                        output.add(new FileCandidate(file, "Old archive • " + ageDays + " days old", false));
                    } else if (file.length() >= 500L * 1024 * 1024) {
                        output.add(new FileCandidate(file, "Very large file", false));
                    } else if (file.getParentFile() != null
                            && file.getParentFile().getName().equalsIgnoreCase(".thumbnails")
                            && ageDays >= 30) {
                        output.add(new FileCandidate(file, "Old thumbnail cache • " + ageDays + " days old", true));
                    }
                }
            }
        }
        output.sort((a, b) -> Long.compare(b.file.length(), a.file.length()));
        if (output.size() > 1000) return new ArrayList<>(output.subList(0, 1000));
        return output;
    }

    private void showCandidates(List<FileCandidate> candidates) {
        progress.setVisibility(View.GONE);
        results.removeAllViews();
        selections.clear();
        if (candidates.isEmpty()) {
            status.setText("No obvious junk or abandoned public files were found.");
            delete.setVisibility(View.GONE);
            return;
        }
        long total = 0;
        for (FileCandidate candidate : candidates) {
            LinearLayout card = Ui.card(this);
            CheckBox box = new CheckBox(this);
            String size = candidate.file.isDirectory() ? "Folder" : Formatters.bytes(candidate.file.length());
            box.setText(candidate.file.getName() + "\n" + size + " • " + candidate.reason
                    + "\n" + candidate.file.getAbsolutePath());
            box.setTextColor(Color.rgb(31, 44, 62));
            box.setTextSize(14);
            box.setChecked(candidate.suggested);
            card.addView(box);
            results.addView(card);
            selections.put(box, candidate);
            total += candidate.file.length();
        }
        status.setText(candidates.size() + " review items found • Up to " + Formatters.bytes(total)
                + " listed. Suggested selections are conservative.");
        delete.setVisibility(View.VISIBLE);
    }

    private void confirmDelete() {
        List<FileCandidate> selected = new ArrayList<>();
        long total = 0;
        for (Map.Entry<CheckBox, FileCandidate> entry : selections.entrySet()) {
            if (entry.getKey().isChecked()) {
                selected.add(entry.getValue());
                total += entry.getValue().file.length();
            }
        }
        if (selected.isEmpty()) {
            Toast.makeText(this, "Select at least one item", Toast.LENGTH_SHORT).show();
            return;
        }
        long finalTotal = total;
        new AlertDialog.Builder(this)
                .setTitle("Permanently delete selected files?")
                .setMessage(selected.size() + " items totaling about " + Formatters.bytes(finalTotal)
                        + " will be deleted. Unlike media cleanup, this deep-clean action does not use Android trash.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (dialog, which) -> deleteFiles(selected))
                .show();
    }

    private void deleteFiles(List<FileCandidate> selected) {
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(false);
        delete.setVisibility(View.GONE);
        executor.submit(() -> {
            int success = 0;
            for (int i = 0; i < selected.size(); i++) {
                File file = selected.get(i).file;
                boolean wasFile = file.isFile();
                String deletedPath = file.getAbsolutePath();
                boolean removed = file.delete();
                if (removed) {
                    success++;
                    if (wasFile) MediaScannerConnection.scanFile(this, new String[]{deletedPath}, null, null);
                }
                int done = i + 1;
                runOnUiThread(() -> {
                    progress.setProgress(Math.round(done * 100f / selected.size()));
                    status.setText("Deleting " + done + " of " + selected.size() + "…");
                });
            }
            int finalSuccess = success;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                status.setText("Deleted " + finalSuccess + " of " + selected.size() + " selected items.");
                runScan();
            });
        });
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
