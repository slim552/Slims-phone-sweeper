package com.slimproductions.phonesweep;

import android.net.Uri;

public final class MediaItem {
    public long id;
    public Uri uri;
    public String name = "Unknown";
    public String mime = "";
    public String relativePath = "";
    public String artist = "Unknown Artist";
    public String album = "Unknown Album";
    public long size;
    public long modified;
    public long dateTaken;
    public int width;
    public int height;
    public String hash = "";
    public long perceptualHash;

    public String description() {
        String details = Formatters.bytes(size) + " • " + Formatters.date(modified);
        if (width > 0 && height > 0) details += " • " + width + "×" + height;
        if (relativePath != null && !relativePath.isEmpty()) details += "\n" + relativePath;
        return details;
    }
}
