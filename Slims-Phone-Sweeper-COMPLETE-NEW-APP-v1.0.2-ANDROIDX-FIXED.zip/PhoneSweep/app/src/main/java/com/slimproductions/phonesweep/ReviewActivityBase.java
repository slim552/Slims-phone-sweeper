package com.slimproductions.phonesweep;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public abstract class ReviewActivityBase extends BaseActivity {
    protected LinearLayout root;
    protected LinearLayout results;
    protected TextView status;
    protected ProgressBar progress;
    protected Button primaryAction;
    protected final Map<CheckBox, MediaItem> selections = new LinkedHashMap<>();

    protected void setup(String title, String description, String actionText) {
        root = Ui.screen(this);
        root.addView(Ui.title(this, title));
        root.addView(Ui.subtitle(this, description));
        status = Ui.body(this, "Ready");
        root.addView(status);
        progress = Ui.progress(this);
        root.addView(progress);
        results = new LinearLayout(this);
        results.setOrientation(LinearLayout.VERTICAL);
        root.addView(results);
        primaryAction = Ui.button(this, actionText);
        primaryAction.setVisibility(View.GONE);
        primaryAction.setOnClickListener(v -> trashSelected());
        root.addView(primaryAction);
        setContentView(Ui.scrollScreen(this, root));
    }

    protected void showProgress(int done, int total, String message) {
        runOnUiThread(() -> {
            progress.setVisibility(View.VISIBLE);
            progress.setIndeterminate(total <= 0);
            if (total > 0) progress.setProgress(Math.min(100, Math.round(done * 100f / total)));
            status.setText(message + (total > 0 ? "  (" + done + "/" + total + ")" : ""));
        });
    }

    protected void showGroups(List<List<MediaItem>> groups, boolean preselectExtras, String emptyMessage) {
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            results.removeAllViews();
            selections.clear();
            if (groups == null || groups.isEmpty()) {
                status.setText(emptyMessage);
                primaryAction.setVisibility(View.GONE);
                return;
            }
            long reclaimable = 0;
            int number = 1;
            for (List<MediaItem> group : groups) {
                if (group == null || group.size() < 2) continue;
                LinearLayout card = Ui.card(this);
                TextView heading = Ui.section(this, "Group " + number + " • " + group.size() + " files");
                card.addView(heading);
                long groupTotal = ScanUtils.totalSize(group);
                String guidance = preselectExtras
                        ? "\nThe oldest item is the recommended keep; all other exact copies are preselected."
                        : "\nNothing is preselected. The highest-resolution item is listed first as a reference.";
                card.addView(Ui.body(this, "Combined size: " + Formatters.bytes(groupTotal) + guidance));
                for (int i = 0; i < group.size(); i++) {
                    MediaItem item = group.get(i);
                    CheckBox box = new CheckBox(this);
                    String prefix = preselectExtras ? (i == 0 ? "KEEP  " : "REMOVE  ") : (i == 0 ? "REFERENCE  " : "REVIEW  ");
                    box.setText(prefix + item.name + "\n" + item.description());
                    box.setTextColor(Color.rgb(31, 44, 62));
                    box.setTextSize(14);
                    box.setPadding(0, Ui.dp(this, 5), 0, Ui.dp(this, 5));
                    box.setChecked(preselectExtras && i > 0);
                    selections.put(box, item);
                    card.addView(box);
                    if (i > 0) reclaimable += item.size;
                }
                results.addView(card);
                number++;
            }
            String summary = preselectExtras
                    ? groups.size() + " groups found • About " + Formatters.bytes(reclaimable) + " is preselected for recovery"
                    : groups.size() + " groups found • Up to " + Formatters.bytes(reclaimable) + " may be recoverable after manual review";
            status.setText(summary);
            primaryAction.setVisibility(View.VISIBLE);
        });
    }

    protected void showItems(List<MediaItem> items, boolean preselect, String emptyMessage) {
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            results.removeAllViews();
            selections.clear();
            if (items == null || items.isEmpty()) {
                status.setText(emptyMessage);
                primaryAction.setVisibility(View.GONE);
                return;
            }
            long total = 0;
            int count = 0;
            for (MediaItem item : items) {
                CheckBox box = new CheckBox(this);
                box.setText(item.name + "\n" + item.description());
                box.setTextColor(Color.rgb(31, 44, 62));
                box.setTextSize(14);
                box.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 8));
                box.setChecked(preselect);
                LinearLayout card = Ui.card(this);
                card.addView(box);
                results.addView(card);
                selections.put(box, item);
                total += item.size;
                count++;
            }
            status.setText(count + " files found • " + Formatters.bytes(total) + " total");
            primaryAction.setVisibility(View.VISIBLE);
        });
    }

    protected List<MediaItem> selectedItems() {
        List<MediaItem> selected = new ArrayList<>();
        for (Map.Entry<CheckBox, MediaItem> entry : selections.entrySet()) {
            if (entry.getKey().isChecked()) selected.add(entry.getValue());
        }
        return selected;
    }

    protected void trashSelected() {
        List<MediaItem> selected = selectedItems();
        List<android.net.Uri> uris = new ArrayList<>();
        for (MediaItem item : selected) uris.add(item.uri);
        DeleteHelper.moveToTrash(this, uris);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DeleteHelper.REQUEST_TRASH) {
            if (resultCode == Activity.RESULT_OK) {
                Toast.makeText(this, "Moved to Android trash", Toast.LENGTH_LONG).show();
                rerunAfterDelete();
            } else {
                Toast.makeText(this, "Nothing was removed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    protected abstract void rerunAfterDelete();
}
