package com.slimproductions.phonesweep;

import android.net.Uri;

public final class MovePlan {
    public Uri uri;
    public String name;
    public String from;
    public String to;
    public boolean directFile;
    public String sourceFilePath;
    public String targetDirectoryPath;

    public MovePlan(Uri uri, String name, String from, String to) {
        this.uri = uri;
        this.name = name;
        this.from = from;
        this.to = to;
        this.directFile = false;
    }

    public static MovePlan directFile(String sourceFilePath, String name, String from, String targetDirectoryPath) {
        MovePlan plan = new MovePlan(null, name, from, targetDirectoryPath);
        plan.directFile = true;
        plan.sourceFilePath = sourceFilePath;
        plan.targetDirectoryPath = targetDirectoryPath;
        return plan;
    }
}
