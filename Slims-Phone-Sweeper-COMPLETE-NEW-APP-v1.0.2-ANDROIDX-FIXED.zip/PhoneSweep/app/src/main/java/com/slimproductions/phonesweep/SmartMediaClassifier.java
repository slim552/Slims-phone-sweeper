package com.slimproductions.phonesweep;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Size;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.label.ImageLabel;
import com.google.mlkit.vision.label.ImageLabeler;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public final class SmartMediaClassifier {
    private SmartMediaClassifier() {}

    public static LinkedHashMap<String, List<String>> parseRules(String raw) {
        LinkedHashMap<String, List<String>> result = new LinkedHashMap<>();
        if (raw == null) return result;
        String[] lines = raw.split("\\r?\\n");
        for (String line : lines) {
            String trimmed = line.trim();
            if (trimmed.isEmpty() || trimmed.startsWith("#")) continue;
            int equals = trimmed.indexOf('=');
            if (equals <= 0 || equals >= trimmed.length() - 1) continue;
            String category = safeFolder(trimmed.substring(0, equals).trim(), "Other");
            String[] pieces = trimmed.substring(equals + 1).split(",");
            List<String> keywords = new ArrayList<>();
            for (String piece : pieces) {
                String keyword = normalize(piece);
                if (!keyword.isEmpty()) keywords.add(keyword);
            }
            if (!keywords.isEmpty()) result.put(category, keywords);
        }
        return result;
    }

    public static List<String> readVisualLabels(Context context, ImageLabeler labeler, MediaItem item) {
        List<String> labels = new ArrayList<>();
        try {
            Bitmap bitmap = context.getContentResolver().loadThumbnail(item.uri, new Size(320, 320), null);
            if (bitmap == null) return labels;
            InputImage image = InputImage.fromBitmap(bitmap, 0);
            List<ImageLabel> found = Tasks.await(labeler.process(image), 20, TimeUnit.SECONDS);
            for (ImageLabel label : found) {
                if (label.getConfidence() >= 0.55f) labels.add(label.getText());
            }
            bitmap.recycle();
        } catch (Exception ignored) {}
        return labels;
    }

    public static String visualCategory(MediaItem item, List<String> labels,
                                        LinkedHashMap<String, List<String>> customRules) {
        String combined = searchable(item, labels);

        String custom = matchRules(combined, customRules);
        if (custom != null) return custom;

        if (containsAny(combined, "screenshot", "screen capture", "screen shot")) return "Screenshots";

        if (isChristmasWindow(item) && containsAny(combined,
                "christmas", "xmas", "santa", "holiday", "ornament", "gift", "present",
                "christmas tree", "snowman", "wreath", "decoration")) return "Christmas";

        if (containsAny(combined,
                "child", "children", "kid", "kids", "baby", "infant", "toddler",
                "school", "playground", "family")) return "Kids & Family";

        if (containsAny(combined,
                "dog", "puppy", "canine", "pet", "cat", "kitten", "feline", "animal")) return "Puppy & Pets";

        if (containsAny(combined,
                "document", "text", "receipt", "invoice", "letter", "paper", "handwriting",
                "business card", "book", "menu", "form")) return "Documents & Receipts";

        if (containsAny(combined,
                "selfie", "portrait", "person", "people", "face", "human", "crowd")) return "People & Selfies";

        if (containsAny(combined,
                "food", "meal", "dish", "drink", "beverage", "restaurant", "dessert", "cake")) return "Food & Drinks";

        if (containsAny(combined,
                "car", "vehicle", "truck", "motorcycle", "bicycle", "boat", "airplane", "train")) return "Vehicles";

        if (containsAny(combined,
                "concert", "party", "stage", "performance", "festival", "wedding", "birthday")) return "Events & Parties";

        if (containsAny(combined,
                "nature", "landscape", "sky", "cloud", "sunset", "sunrise", "tree", "flower",
                "beach", "mountain", "lake", "river", "forest", "snow")) return "Nature & Outdoors";

        if (containsAny(combined,
                "drawing", "illustration", "cartoon", "art", "painting", "graphic", "meme")) return "Art & Memes";

        return "Other";
    }

    public static String musicTarget(MediaItem item, LinkedHashMap<String, List<String>> customRules) {
        String combined = normalize(item.name + " " + item.relativePath + " " + item.artist + " " + item.album);
        String custom = matchRules(combined, customRules);
        if (custom != null) return "Music/PhoneSweep/" + custom + "/";

        if (containsAny(combined,
                "stem", "stems", "acapella", "a cappella", "vocal only", "vocals",
                "drum", "drums", "bass", "guitar", "piano", "keys", "kick", "snare", "808")) {
            return "Music/PhoneSweep/Stems/";
        }
        if (containsAny(combined,
                "instrumental", "instramental", "beat", "karaoke", "no vocals", "music only")) {
            return "Music/PhoneSweep/Instrumentals/";
        }
        if (containsAny(combined,
                "master", "mastered", "mixdown", "final mix", "finalmaster")) {
            return "Music/PhoneSweep/Masters/";
        }
        if (containsAny(combined,
                "demo", "rough", "draft", "idea", "reference", "preview")) {
            return "Music/PhoneSweep/Demos & Drafts/";
        }
        if (containsAny(combined,
                "recording", "voice note", "voice memo", "memo")) {
            return "Music/PhoneSweep/Recordings/";
        }

        String artist = ScanUtils.safeFolder(item.artist, "Unknown Artist");
        String album = ScanUtils.safeFolder(item.album, "Unknown Album");
        if (!"Unknown Album".equalsIgnoreCase(album)) {
            return "Music/PhoneSweep/Albums/" + artist + "/" + album + "/";
        }
        return "Music/PhoneSweep/Singles/" + artist + "/";
    }

    public static String downloadCategory(String fileName) {
        String lower = normalize(fileName);
        if (endsWithAny(lower, ".pdf")) return "PDFs";
        if (endsWithAny(lower, ".doc", ".docx", ".odt", ".rtf", ".txt")) return "Documents";
        if (endsWithAny(lower, ".xls", ".xlsx", ".ods", ".csv")) return "Spreadsheets";
        if (endsWithAny(lower, ".ppt", ".pptx", ".odp")) return "Presentations";
        if (endsWithAny(lower, ".zip", ".rar", ".7z", ".tar", ".gz")) return "Archives";
        if (endsWithAny(lower, ".apk", ".apks", ".xapk")) return "APK Installers";
        if (endsWithAny(lower, ".jpg", ".jpeg", ".png", ".webp", ".gif", ".heic")) return "Images";
        if (endsWithAny(lower, ".mp3", ".wav", ".m4a", ".aac", ".flac", ".ogg")) return "Audio";
        if (endsWithAny(lower, ".mp4", ".mkv", ".mov", ".avi", ".webm")) return "Videos";
        if (endsWithAny(lower, ".html", ".htm", ".json", ".xml", ".yml", ".yaml")) return "Web & Data";
        return "Other Files";
    }

    public static String datedVisualTarget(boolean video, String category, MediaItem item) {
        long timestampMs = item.dateTaken > 0 ? item.dateTaken : item.modified * 1000L;
        if (timestampMs <= 0) timestampMs = System.currentTimeMillis();
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(timestampMs));
        String root = video ? "Movies" : "Pictures";
        return String.format(Locale.US, "%s/PhoneSweep/%s/%04d/%02d/", root,
                safeFolder(category, "Other"), cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
    }

    private static boolean isChristmasWindow(MediaItem item) {
        long timestampMs = item.dateTaken > 0 ? item.dateTaken : item.modified * 1000L;
        if (timestampMs <= 0) return false;
        Calendar cal = Calendar.getInstance();
        cal.setTime(new Date(timestampMs));
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        return (month == Calendar.DECEMBER && day >= 15) || (month == Calendar.JANUARY && day <= 7);
    }

    private static String searchable(MediaItem item, List<String> labels) {
        StringBuilder out = new StringBuilder();
        out.append(item.name).append(' ').append(item.relativePath).append(' ');
        for (String label : labels) out.append(label).append(' ');
        return normalize(out.toString());
    }

    private static String matchRules(String combined, LinkedHashMap<String, List<String>> rules) {
        if (rules == null) return null;
        for (Map.Entry<String, List<String>> entry : rules.entrySet()) {
            for (String keyword : entry.getValue()) {
                if (!keyword.isEmpty() && combined.contains(keyword)) return entry.getKey();
            }
        }
        return null;
    }

    private static boolean containsAny(String text, String... terms) {
        for (String term : terms) if (text.contains(normalize(term))) return true;
        return false;
    }

    private static boolean endsWithAny(String text, String... endings) {
        for (String ending : endings) if (text.endsWith(ending)) return true;
        return false;
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.US).replace('_', ' ').replace('-', ' ').trim();
    }

    private static String safeFolder(String value, String fallback) {
        if (value == null || value.trim().isEmpty()) return fallback;
        String cleaned = value.replaceAll("[\\\\/:*?\"<>|]", " ")
                .replaceAll("\\s+", " ").trim();
        return cleaned.isEmpty() ? fallback : cleaned;
    }
}
