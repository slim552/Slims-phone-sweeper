package com.slimproductions.phonesweep;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.media.MediaScannerConnection;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.mlkit.vision.label.ImageLabeler;
import com.google.mlkit.vision.label.ImageLabeling;
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OrganizerActivity extends BaseActivity {
    private static final int MAX_AI_ITEMS_PER_RUN = 1000;
    private static final int MAX_DOWNLOAD_FILES_PER_RUN = 2000;

    private static final String DEFAULT_VISUAL_RULES =
            "Kids & Family=child,baby,infant,toddler,kid,kids,school,playground,family\n" +
            "Christmas=christmas,xmas,santa,holiday,christmas tree,gift,present,ornament,wreath\n" +
            "Puppy & Pets=dog,puppy,pet,cat,kitten,animal";

    private static final String DEFAULT_MUSIC_RULES =
            "Stems=stem,stems,vocals,acapella,a cappella,drums,bass,guitar,piano,keys,kick,snare,808\n" +
            "Instrumentals=instrumental,instramental,beat,karaoke,no vocals,music only\n" +
            "Masters=master,mastered,mixdown,final mix,finalmaster\n" +
            "Demos & Drafts=demo,rough,draft,idea,reference,preview\n" +
            "Recordings=recording,voice note,voice memo,memo";

    private LinearLayout preview;
    private TextView status;
    private ProgressBar progress;
    private Button apply;
    private EditText visualRules;
    private EditText musicRules;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final List<MovePlan> pending = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        root.addView(Ui.title(this, "Smart organizer"));
        root.addView(Ui.subtitle(this,
                "Sort photos, videos, music and downloads into useful folders. Smart photo and video sorting uses private on-device image labeling. Every move is previewed first."));

        LinearLayout rulesCard = Ui.card(this);
        rulesCard.addView(Ui.section(this, "Your smart folders"));
        rulesCard.addView(Ui.body(this,
                "Write one folder per line as Folder name=keyword,keyword. These rules are checked before the built-in categories. You can add folders such as Logan, J.J., Studio, Cars or Holidays."));

        rulesCard.addView(Ui.subtitle(this, "Photo and video rules"));
        visualRules = new EditText(this);
        visualRules.setMinLines(4);
        visualRules.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        visualRules.setText(getPreferences(MODE_PRIVATE).getString("visual_rules", DEFAULT_VISUAL_RULES));
        rulesCard.addView(visualRules);

        rulesCard.addView(Ui.subtitle(this, "Music rules"));
        musicRules = new EditText(this);
        musicRules.setMinLines(5);
        musicRules.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        musicRules.setText(getPreferences(MODE_PRIVATE).getString("music_rules", DEFAULT_MUSIC_RULES));
        rulesCard.addView(musicRules);

        Button saveRules = Ui.secondaryButton(this, "Save folder rules");
        saveRules.setOnClickListener(v -> saveRules());
        rulesCard.addView(saveRules);
        root.addView(rulesCard);

        status = Ui.body(this, "Choose what you want to organize.");
        root.addView(status);
        progress = Ui.progress(this);
        root.addView(progress);

        root.addView(Ui.section(this, "Smart sorting"));
        Button smartPhotos = Ui.button(this, "Preview smart photo sorting");
        smartPhotos.setOnClickListener(v -> previewVisual(false));
        root.addView(smartPhotos);

        Button smartVideos = Ui.secondaryButton(this, "Preview smart video sorting");
        smartVideos.setOnClickListener(v -> previewVisual(true));
        root.addView(smartVideos);

        Button smartMusic = Ui.secondaryButton(this, "Preview music type and album sorting");
        smartMusic.setOnClickListener(v -> previewSmartMusic());
        root.addView(smartMusic);

        Button downloads = Ui.secondaryButton(this, "Preview Downloads sorting by file type");
        downloads.setOnClickListener(v -> previewDownloads());
        root.addView(downloads);

        root.addView(Ui.section(this, "Classic sorting"));
        Button photosByDate = Ui.secondaryButton(this, "Photos by year and month");
        photosByDate.setOnClickListener(v -> previewPhotosByDate());
        root.addView(photosByDate);

        Button musicByAlbum = Ui.secondaryButton(this, "Music by artist and album");
        musicByAlbum.setOnClickListener(v -> previewMusicByAlbum());
        root.addView(musicByAlbum);

        preview = new LinearLayout(this);
        preview.setOrientation(LinearLayout.VERTICAL);
        root.addView(preview);

        apply = Ui.button(this, "Apply organization");
        apply.setVisibility(View.GONE);
        apply.setOnClickListener(v -> requestApply());
        root.addView(apply);

        LinearLayout safety = Ui.card(this);
        safety.addView(Ui.section(this, "Safety"));
        safety.addView(Ui.body(this,
                "Slims Phone Sweeper never silently moves anything. AI labels can make mistakes, especially when distinguishing children from adults, so review the destination list before approving. The first 200 media moves are applied per approval; run the scan again to continue."));
        root.addView(safety);

        setContentView(Ui.scrollScreen(this, root));
    }

    private void saveRules() {
        getPreferences(MODE_PRIVATE).edit()
                .putString("visual_rules", visualRules.getText().toString())
                .putString("music_rules", musicRules.getText().toString())
                .apply();
        Toast.makeText(this, "Folder rules saved", Toast.LENGTH_SHORT).show();
    }

    private boolean ensurePermission(String type) {
        boolean granted;
        if ("photos".equals(type)) granted = PermissionHelper.hasImagePermission(this);
        else if ("videos".equals(type)) granted = PermissionHelper.hasVideoPermission(this);
        else granted = PermissionHelper.hasAudioPermission(this);
        if (!granted) {
            PermissionHelper.requestMediaPermissions(this);
            status.setText("Grant " + type + " access, then choose this mode again.");
            return false;
        }
        return true;
    }

    private void previewVisual(boolean videos) {
        if (!ensurePermission(videos ? "videos" : "photos")) return;
        saveRules();
        final String rulesText = visualRules.getText().toString();
        startBusy("Reading " + (videos ? "video thumbnails" : "photos") + " with on-device AI…");
        executor.submit(() -> {
            List<MediaItem> source = videos ? ScanUtils.queryVideos(this) : ScanUtils.queryImages(this);
            List<MediaItem> candidates = new ArrayList<>();
            String organizedRoot = videos ? "movies/phonesweep/" : "pictures/phonesweep/";
            for (MediaItem item : source) {
                if (!normalize(item.relativePath).startsWith(organizedRoot)) candidates.add(item);
            }
            List<MovePlan> plans = new ArrayList<>();
            LinkedHashMap<String, List<String>> rules =
                    SmartMediaClassifier.parseRules(rulesText);
            ImageLabeler labeler = ImageLabeling.getClient(ImageLabelerOptions.DEFAULT_OPTIONS);
            int total = Math.min(candidates.size(), MAX_AI_ITEMS_PER_RUN);
            try {
                for (int i = 0; i < total; i++) {
                    MediaItem item = candidates.get(i);
                    List<String> labels = SmartMediaClassifier.readVisualLabels(this, labeler, item);
                    String category = SmartMediaClassifier.visualCategory(item, labels, rules);
                    String target = SmartMediaClassifier.datedVisualTarget(videos, category, item);
                    String current = item.relativePath == null ? "" : item.relativePath;
                    if (!normalize(current).equals(normalize(target))) {
                        plans.add(new MovePlan(item.uri, item.name, current, target));
                    }
                    int done = i + 1;
                    runOnUiThread(() -> {
                        progress.setIndeterminate(false);
                        progress.setProgress(Math.round(done * 100f / Math.max(1, total)));
                        status.setText("Classifying " + done + " of " + total + "…");
                    });
                }
            } finally {
                labeler.close();
            }
            String note = candidates.size() > MAX_AI_ITEMS_PER_RUN
                    ? " This run checked the next " + MAX_AI_ITEMS_PER_RUN + " unsorted items; run it again after moving them to continue."
                    : "";
            showPreview(plans, videos ? "videos" : "photos", note);
        });
    }

    private void previewSmartMusic() {
        if (!ensurePermission("music")) return;
        saveRules();
        final String rulesText = musicRules.getText().toString();
        startBusy("Reading music names and metadata…");
        executor.submit(() -> {
            List<MovePlan> plans = new ArrayList<>();
            LinkedHashMap<String, List<String>> rules =
                    SmartMediaClassifier.parseRules(rulesText);
            List<MediaItem> items = ScanUtils.queryAudio(this);
            int total = items.size();
            for (int i = 0; i < total; i++) {
                MediaItem item = items.get(i);
                String target = SmartMediaClassifier.musicTarget(item, rules);
                String current = item.relativePath == null ? "" : item.relativePath;
                if (!normalize(current).equals(normalize(target))) {
                    plans.add(new MovePlan(item.uri, item.name, current, target));
                }
                updateSimpleProgress(i + 1, total, "Reading music");
            }
            showPreview(plans, "music files", "");
        });
    }

    private void previewPhotosByDate() {
        if (!ensurePermission("photos")) return;
        startBusy("Building a photo date preview…");
        executor.submit(() -> {
            List<MovePlan> plans = new ArrayList<>();
            List<MediaItem> items = ScanUtils.queryImages(this);
            for (int i = 0; i < items.size(); i++) {
                MediaItem item = items.get(i);
                long timestampMs = item.dateTaken > 0 ? item.dateTaken : item.modified * 1000L;
                Calendar cal = Calendar.getInstance();
                if (timestampMs <= 0) timestampMs = System.currentTimeMillis();
                cal.setTime(new Date(timestampMs));
                String target = String.format(Locale.US, "Pictures/PhoneSweep/By Date/%04d/%02d/",
                        cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1);
                String current = item.relativePath == null ? "" : item.relativePath;
                if (!normalize(current).equals(normalize(target))) {
                    plans.add(new MovePlan(item.uri, item.name, current, target));
                }
                updateSimpleProgress(i + 1, items.size(), "Reading photos");
            }
            showPreview(plans, "photos", "");
        });
    }

    private void previewMusicByAlbum() {
        if (!ensurePermission("music")) return;
        startBusy("Building a music album preview…");
        executor.submit(() -> {
            List<MovePlan> plans = new ArrayList<>();
            List<MediaItem> items = ScanUtils.queryAudio(this);
            for (int i = 0; i < items.size(); i++) {
                MediaItem item = items.get(i);
                String artist = ScanUtils.safeFolder(item.artist, "Unknown Artist");
                String album = ScanUtils.safeFolder(item.album, "Unknown Album");
                String target = "Music/PhoneSweep/Albums/" + artist + "/" + album + "/";
                String current = item.relativePath == null ? "" : item.relativePath;
                if (!normalize(current).equals(normalize(target))) {
                    plans.add(new MovePlan(item.uri, item.name, current, target));
                }
                updateSimpleProgress(i + 1, items.size(), "Reading music");
            }
            showPreview(plans, "music files", "");
        });
    }

    private void previewDownloads() {
        if (!PermissionHelper.hasAllFilesAccess()) {
            status.setText("Downloads sorting needs the optional full file access permission. Grant it, return here, then try again.");
            PermissionHelper.requestAllFilesAccess(this);
            return;
        }
        startBusy("Reading the Downloads folder…");
        executor.submit(() -> {
            List<MovePlan> plans = new ArrayList<>();
            File downloads = new File(Environment.getExternalStorageDirectory(), "Download");
            List<File> files = new ArrayList<>();
            collectFiles(downloads, files, MAX_DOWNLOAD_FILES_PER_RUN);
            for (int i = 0; i < files.size(); i++) {
                File file = files.get(i);
                String absolute = file.getAbsolutePath().replace('\\', '/');
                if (absolute.contains("/Download/PhoneSweep/")) continue;
                String category = SmartMediaClassifier.downloadCategory(file.getName());
                File targetDirectory = new File(downloads, "PhoneSweep/" + category);
                plans.add(MovePlan.directFile(file.getAbsolutePath(), file.getName(),
                        file.getParent(), targetDirectory.getAbsolutePath()));
                updateSimpleProgress(i + 1, files.size(), "Reading downloads");
            }
            String note = files.size() >= MAX_DOWNLOAD_FILES_PER_RUN
                    ? " This run found the first " + MAX_DOWNLOAD_FILES_PER_RUN + " files."
                    : "";
            showPreview(plans, "downloaded files", note);
        });
    }

    private static void collectFiles(File directory, List<File> out, int limit) {
        if (directory == null || !directory.isDirectory() || out.size() >= limit) return;
        File[] children = directory.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (out.size() >= limit) return;
            if (child.getName().startsWith(".")) continue;
            if (child.isDirectory()) {
                if ("PhoneSweep".equalsIgnoreCase(child.getName())) continue;
                collectFiles(child, out, limit);
            } else if (child.isFile()) {
                out.add(child);
            }
        }
    }

    private void updateSimpleProgress(int done, int total, String label) {
        if (done % 10 != 0 && done != total) return;
        runOnUiThread(() -> {
            progress.setIndeterminate(false);
            progress.setProgress(Math.round(done * 100f / Math.max(1, total)));
            status.setText(label + " " + done + " of " + total + "…");
        });
    }

    private void startBusy(String message) {
        pending.clear();
        preview.removeAllViews();
        apply.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        progress.setProgress(0);
        status.setText(message);
    }

    private void showPreview(List<MovePlan> plans, String label, String note) {
        runOnUiThread(() -> {
            progress.setVisibility(View.GONE);
            preview.removeAllViews();
            pending.clear();
            pending.addAll(plans);
            if (plans.isEmpty()) {
                status.setText("Everything checked already appears organized." + note);
                apply.setVisibility(View.GONE);
                return;
            }
            int shown = Math.min(100, plans.size());
            for (int i = 0; i < shown; i++) {
                MovePlan plan = plans.get(i);
                LinearLayout card = Ui.card(this);
                card.addView(Ui.section(this, plan.name));
                card.addView(Ui.body(this, "From: " + displayPath(plan.from) + "\nTo: " + plan.to));
                preview.addView(card);
            }
            if (plans.size() > shown) {
                preview.addView(Ui.subtitle(this,
                        "+ " + (plans.size() - shown) + " more changes not shown in this preview"));
            }
            status.setText(plans.size() + " " + label + " can be organized." + note);
            apply.setVisibility(View.VISIBLE);
        });
    }

    private void requestApply() {
        if (pending.isEmpty()) return;
        if (pending.get(0).directFile) {
            new AlertDialog.Builder(this)
                    .setTitle("Move downloaded files?")
                    .setMessage("Slims Phone Sweeper will move the reviewed files into Download/PhoneSweep category folders. Nothing will be deleted.")
                    .setNegativeButton("Cancel", null)
                    .setPositiveButton("Move files", (dialog, which) -> applyMoves())
                    .show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 30) {
            List<android.net.Uri> uris = new ArrayList<>();
            for (int i = 0; i < Math.min(200, pending.size()); i++) uris.add(pending.get(i).uri);
            if (pending.size() > 200) {
                Toast.makeText(this,
                        "Android approves moves in batches. This run will organize the first 200 files.",
                        Toast.LENGTH_LONG).show();
            }
            DeleteHelper.requestWrite(this, uris);
        } else {
            applyMoves();
        }
    }

    private void applyMoves() {
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(false);
        progress.setProgress(0);
        apply.setVisibility(View.GONE);
        executor.submit(() -> {
            int success = 0;
            boolean direct = !pending.isEmpty() && pending.get(0).directFile;
            int limit = direct ? pending.size() : Math.min(200, pending.size());
            for (int i = 0; i < limit; i++) {
                MovePlan plan = pending.get(i);
                boolean moved = direct ? moveDirectFile(plan) : moveMedia(plan);
                if (moved) success++;
                int done = i + 1;
                runOnUiThread(() -> {
                    progress.setProgress(Math.round(done * 100f / Math.max(1, limit)));
                    status.setText("Organizing " + done + " of " + limit + "…");
                });
            }
            int finalSuccess = success;
            runOnUiThread(() -> {
                progress.setVisibility(View.GONE);
                status.setText("Organized " + finalSuccess + " of " + limit +
                        " files. Run the preview again to continue or verify the result.");
                pending.clear();
                preview.removeAllViews();
            });
        });
    }

    private boolean moveMedia(MovePlan plan) {
        try {
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.RELATIVE_PATH, plan.to);
            return getContentResolver().update(plan.uri, values, null, null) > 0;
        } catch (Exception ignored) {
            return false;
        }
    }

    private boolean moveDirectFile(MovePlan plan) {
        try {
            File source = new File(plan.sourceFilePath);
            if (!source.isFile()) return false;
            File directory = new File(plan.targetDirectoryPath);
            if (!directory.exists() && !directory.mkdirs()) return false;
            File target = uniqueTarget(directory, source.getName());
            boolean moved = source.renameTo(target);
            if (!moved) {
                copyFile(source, target);
                moved = source.delete();
                if (!moved) target.delete();
            }
            if (moved) {
                MediaScannerConnection.scanFile(this,
                        new String[]{source.getAbsolutePath(), target.getAbsolutePath()}, null, null);
            }
            return moved;
        } catch (Exception ignored) {
            return false;
        }
    }

    private static File uniqueTarget(File directory, String name) {
        File target = new File(directory, name);
        if (!target.exists()) return target;
        int dot = name.lastIndexOf('.');
        String base = dot > 0 ? name.substring(0, dot) : name;
        String extension = dot > 0 ? name.substring(dot) : "";
        for (int i = 2; i < 10000; i++) {
            target = new File(directory, base + " (" + i + ")" + extension);
            if (!target.exists()) return target;
        }
        return new File(directory, System.currentTimeMillis() + "-" + name);
    }

    private static void copyFile(File source, File target) throws Exception {
        byte[] buffer = new byte[1024 * 128];
        try (FileInputStream in = new FileInputStream(source);
             FileOutputStream out = new FileOutputStream(target)) {
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            out.getFD().sync();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == DeleteHelper.REQUEST_WRITE) {
            if (resultCode == Activity.RESULT_OK) applyMoves();
            else Toast.makeText(this, "Organization cancelled", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQUEST_MEDIA) {
            status.setText("Permission updated. Choose the sorting mode again.");
        }
    }

    private static String normalize(String path) {
        if (path == null) return "";
        return path.replace('\\', '/').replaceAll("/+", "/").toLowerCase(Locale.US);
    }

    private static String displayPath(String path) {
        return path == null || path.isEmpty() ? "Current folder" : path;
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
