package com.slimproductions.phonesweep;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static LinearLayout screen(Context c) {
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(c, 18), dp(c, 18), dp(c, 18), dp(c, 30));
        root.setBackgroundColor(Color.rgb(244, 247, 251));
        return root;
    }

    public static ScrollView scrollScreen(Context c, LinearLayout content) {
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.addView(content, new ScrollView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return scroll;
    }

    public static TextView title(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(Color.rgb(7, 20, 38));
        v.setTextSize(28);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, 0, 0, dp(c, 6));
        return v;
    }

    public static TextView subtitle(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(Color.rgb(77, 89, 107));
        v.setTextSize(15);
        v.setLineSpacing(0, 1.15f);
        v.setPadding(0, 0, 0, dp(c, 12));
        return v;
    }

    public static TextView section(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(Color.rgb(7, 20, 38));
        v.setTextSize(19);
        v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        v.setPadding(0, dp(c, 8), 0, dp(c, 8));
        return v;
    }

    public static TextView body(Context c, String text) {
        TextView v = new TextView(c);
        v.setText(text);
        v.setTextColor(Color.rgb(45, 57, 74));
        v.setTextSize(15);
        v.setLineSpacing(0, 1.15f);
        return v;
    }

    public static LinearLayout card(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(c, 16), dp(c, 14), dp(c, 16), dp(c, 14));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(c, 18));
        bg.setStroke(dp(c, 1), Color.rgb(226, 232, 241));
        card.setBackground(bg);
        card.setElevation(dp(c, 2));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(c, 12));
        card.setLayoutParams(lp);
        return card;
    }

    public static Button button(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(c, 12), dp(c, 10), dp(c, 12), dp(c, 10));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.rgb(20, 108, 255));
        bg.setCornerRadius(dp(c, 14));
        b.setBackground(bg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 52));
        lp.setMargins(0, dp(c, 8), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = button(c, text);
        b.setTextColor(Color.rgb(20, 108, 255));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.WHITE);
        bg.setCornerRadius(dp(c, 14));
        bg.setStroke(dp(c, 2), Color.rgb(20, 108, 255));
        b.setBackground(bg);
        return b;
    }

    public static ProgressBar progress(Context c) {
        ProgressBar p = new ProgressBar(c, null, android.R.attr.progressBarStyleHorizontal);
        p.setMax(100);
        p.setProgress(0);
        p.setVisibility(View.GONE);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(c, 8));
        lp.setMargins(0, dp(c, 8), 0, dp(c, 8));
        p.setLayoutParams(lp);
        return p;
    }
}
