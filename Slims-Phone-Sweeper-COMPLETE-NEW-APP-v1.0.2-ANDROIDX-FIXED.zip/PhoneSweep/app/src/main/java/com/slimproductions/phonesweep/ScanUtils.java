package com.slimproductions.phonesweep;

import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.Size;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class ScanUtils {
    private ScanUtils() {}

    public interface ProgressListener {
        void onProgress(int done, int total, String message);
    }

    public static List<MediaItem> queryImages(Context context) {
        List<MediaItem> result = new ArrayList<>();
        String[] projection = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DISPLAY_NAME,
                MediaStore.Images.Media.SIZE,
                MediaStore.Images.Media.DATE_MODIFIED,
                MediaStore.Images.Media.DATE_TAKEN,
                MediaStore.Images.Media.MIME_TYPE,
                MediaStore.Images.Media.RELATIVE_PATH,
                MediaStore.Images.Media.WIDTH,
                MediaStore.Images.Media.HEIGHT
        };
        try (Cursor c = context.getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, MediaStore.Images.Media.DATE_MODIFIED + " DESC")) {
            if (c == null) return result;
            int id = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID);
            int name = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME);
            int size = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE);
            int modified = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_MODIFIED);
            int taken = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_TAKEN);
            int mime = c.getColumnIndexOrThrow(MediaStore.Images.Media.MIME_TYPE);
            int path = c.getColumnIndexOrThrow(MediaStore.Images.Media.RELATIVE_PATH);
            int width = c.getColumnIndexOrThrow(MediaStore.Images.Media.WIDTH);
            int height = c.getColumnIndexOrThrow(MediaStore.Images.Media.HEIGHT);
            while (c.moveToNext()) {
                MediaItem item = new MediaItem();
                item.id = c.getLong(id);
                item.uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, item.id);
                item.name = safe(c.getString(name), "Unknown image");
                item.size = c.getLong(size);
                item.modified = c.getLong(modified);
                item.dateTaken = c.getLong(taken);
                item.mime = safe(c.getString(mime), "image/*");
                item.relativePath = safe(c.getString(path), "");
                item.width = c.getInt(width);
                item.height = c.getInt(height);
                result.add(item);
            }
        } catch (Exception ignored) {}
        return result;
    }


    public static List<MediaItem> queryVideos(Context context) {
        List<MediaItem> result = new ArrayList<>();
        String[] projection = {
                MediaStore.Video.Media._ID,
                MediaStore.Video.Media.DISPLAY_NAME,
                MediaStore.Video.Media.SIZE,
                MediaStore.Video.Media.DATE_MODIFIED,
                MediaStore.Video.Media.MIME_TYPE,
                MediaStore.Video.Media.RELATIVE_PATH,
                MediaStore.Video.Media.WIDTH,
                MediaStore.Video.Media.HEIGHT
        };
        try (Cursor c = context.getContentResolver().query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, MediaStore.Video.Media.DATE_MODIFIED + " DESC")) {
            if (c == null) return result;
            int id = c.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
            int name = c.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME);
            int size = c.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE);
            int modified = c.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_MODIFIED);
            int mime = c.getColumnIndexOrThrow(MediaStore.Video.Media.MIME_TYPE);
            int path = c.getColumnIndexOrThrow(MediaStore.Video.Media.RELATIVE_PATH);
            int width = c.getColumnIndexOrThrow(MediaStore.Video.Media.WIDTH);
            int height = c.getColumnIndexOrThrow(MediaStore.Video.Media.HEIGHT);
            while (c.moveToNext()) {
                MediaItem item = new MediaItem();
                item.id = c.getLong(id);
                item.uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, item.id);
                item.name = safe(c.getString(name), "Unknown video");
                item.size = c.getLong(size);
                item.modified = c.getLong(modified);
                item.mime = safe(c.getString(mime), "video/*");
                item.relativePath = safe(c.getString(path), "");
                item.width = c.getInt(width);
                item.height = c.getInt(height);
                result.add(item);
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static List<MediaItem> queryAudio(Context context) {
        List<MediaItem> result = new ArrayList<>();
        String[] projection = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_MODIFIED,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.RELATIVE_PATH,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.ALBUM
        };
        try (Cursor c = context.getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection, null, null, MediaStore.Audio.Media.DATE_MODIFIED + " DESC")) {
            if (c == null) return result;
            int id = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID);
            int name = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME);
            int size = c.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE);
            int modified = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_MODIFIED);
            int mime = c.getColumnIndexOrThrow(MediaStore.Audio.Media.MIME_TYPE);
            int path = c.getColumnIndexOrThrow(MediaStore.Audio.Media.RELATIVE_PATH);
            int artist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST);
            int album = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM);
            while (c.moveToNext()) {
                MediaItem item = new MediaItem();
                item.id = c.getLong(id);
                item.uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, item.id);
                item.name = safe(c.getString(name), "Unknown audio");
                item.size = c.getLong(size);
                item.modified = c.getLong(modified);
                item.mime = safe(c.getString(mime), "audio/*");
                item.relativePath = safe(c.getString(path), "");
                item.artist = safeFolder(c.getString(artist), "Unknown Artist");
                item.album = safeFolder(c.getString(album), "Unknown Album");
                result.add(item);
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static List<MediaItem> queryLargeFiles(Context context, long minimumBytes) {
        List<MediaItem> result = new ArrayList<>();
        Uri collection = MediaStore.Files.getContentUri("external");
        String[] projection = {
                MediaStore.Files.FileColumns._ID,
                MediaStore.Files.FileColumns.DISPLAY_NAME,
                MediaStore.Files.FileColumns.SIZE,
                MediaStore.Files.FileColumns.DATE_MODIFIED,
                MediaStore.Files.FileColumns.MIME_TYPE,
                MediaStore.Files.FileColumns.RELATIVE_PATH
        };
        String selection = MediaStore.Files.FileColumns.SIZE + ">=?";
        String[] args = {Long.toString(minimumBytes)};
        try (Cursor c = context.getContentResolver().query(collection, projection, selection, args,
                MediaStore.Files.FileColumns.SIZE + " DESC")) {
            if (c == null) return result;
            int id = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns._ID);
            int name = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DISPLAY_NAME);
            int size = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.SIZE);
            int modified = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATE_MODIFIED);
            int mime = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.MIME_TYPE);
            int path = c.getColumnIndexOrThrow(MediaStore.Files.FileColumns.RELATIVE_PATH);
            int count = 0;
            while (c.moveToNext() && count < 500) {
                MediaItem item = new MediaItem();
                item.id = c.getLong(id);
                item.uri = ContentUris.withAppendedId(collection, item.id);
                item.name = safe(c.getString(name), "Unknown file");
                item.size = c.getLong(size);
                item.modified = c.getLong(modified);
                item.mime = safe(c.getString(mime), "application/octet-stream");
                item.relativePath = safe(c.getString(path), "");
                result.add(item);
                count++;
            }
        } catch (Exception ignored) {}
        return result;
    }

    public static List<List<MediaItem>> findExactDuplicates(Context context, List<MediaItem> source,
                                                              ProgressListener listener) {
        Map<Long, List<MediaItem>> bySize = new HashMap<>();
        for (MediaItem item : source) {
            if (item.size <= 0) continue;
            bySize.computeIfAbsent(item.size, k -> new ArrayList<>()).add(item);
        }
        List<MediaItem> candidates = new ArrayList<>();
        for (List<MediaItem> group : bySize.values()) if (group.size() > 1) candidates.addAll(group);
        Map<String, List<MediaItem>> byHash = new LinkedHashMap<>();
        int done = 0;
        for (MediaItem item : candidates) {
            item.hash = sha256(context.getContentResolver(), item.uri);
            if (!item.hash.isEmpty()) byHash.computeIfAbsent(item.hash, k -> new ArrayList<>()).add(item);
            done++;
            if (listener != null) listener.onProgress(done, candidates.size(), "Checking " + item.name);
        }
        List<List<MediaItem>> groups = new ArrayList<>();
        for (List<MediaItem> group : byHash.values()) {
            if (group.size() > 1) {
                Collections.sort(group, Comparator.comparingLong(a -> a.modified));
                groups.add(group);
            }
        }
        groups.sort((a, b) -> Long.compare(totalSize(b), totalSize(a)));
        return groups;
    }

    public static List<List<MediaItem>> findSimilarImages(Context context, List<MediaItem> images,
                                                           ProgressListener listener) {
        List<MediaItem> valid = new ArrayList<>();
        int done = 0;
        for (MediaItem item : images) {
            if (item.size > 20_000 && item.width > 0 && item.height > 0) {
                Long hash = dHash(context.getContentResolver(), item.uri);
                if (hash != null) {
                    item.perceptualHash = hash;
                    valid.add(item);
                }
            }
            done++;
            if (listener != null) listener.onProgress(done, images.size(), "Comparing " + item.name);
        }
        Map<Integer, List<List<MediaItem>>> buckets = new HashMap<>();
        for (MediaItem item : valid) {
            int bucket = (int) ((item.perceptualHash >>> 52) & 0xFFF);
            List<List<MediaItem>> bucketGroups = buckets.computeIfAbsent(bucket, k -> new ArrayList<>());
            List<MediaItem> match = null;
            for (List<MediaItem> group : bucketGroups) {
                MediaItem representative = group.get(0);
                if (Long.bitCount(representative.perceptualHash ^ item.perceptualHash) <= 6
                        && aspectClose(representative, item)) {
                    match = group;
                    break;
                }
            }
            if (match == null) {
                match = new ArrayList<>();
                bucketGroups.add(match);
            }
            match.add(item);
        }
        List<List<MediaItem>> groups = new ArrayList<>();
        for (List<List<MediaItem>> bucketGroups : buckets.values()) {
            for (List<MediaItem> group : bucketGroups) {
                if (group.size() > 1) {
                    group.sort((a, b) -> Integer.compare(b.width * b.height, a.width * a.height));
                    groups.add(group);
                }
            }
        }
        groups.sort((a, b) -> Long.compare(totalSize(b), totalSize(a)));
        return groups;
    }

    public static long totalSize(List<MediaItem> items) {
        long total = 0;
        for (MediaItem item : items) total += item.size;
        return total;
    }

    public static String safeFolder(String value, String fallback) {
        String output = safe(value, fallback).trim();
        output = output.replaceAll("[\\\\/:*?\"<>|]", "_");
        output = output.replaceAll("\\s+", " ");
        if (output.length() > 60) output = output.substring(0, 60);
        return output.isEmpty() ? fallback : output;
    }

    private static boolean aspectClose(MediaItem a, MediaItem b) {
        if (a.height == 0 || b.height == 0) return true;
        double arA = (double) a.width / a.height;
        double arB = (double) b.width / b.height;
        return Math.abs(arA - arB) < 0.08;
    }

    private static String sha256(ContentResolver resolver, Uri uri) {
        try (InputStream raw = resolver.openInputStream(uri);
             BufferedInputStream in = raw == null ? null : new BufferedInputStream(raw, 64 * 1024)) {
            if (in == null) return "";
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[64 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) digest.update(buffer, 0, read);
            StringBuilder hex = new StringBuilder();
            for (byte b : digest.digest()) hex.append(String.format(Locale.US, "%02x", b));
            return hex.toString();
        } catch (Exception e) {
            return "";
        }
    }

    private static Long dHash(ContentResolver resolver, Uri uri) {
        Bitmap bitmap = null;
        Bitmap scaled = null;
        try {
            bitmap = resolver.loadThumbnail(uri, new Size(72, 64), null);
            scaled = Bitmap.createScaledBitmap(bitmap, 9, 8, true);
            long hash = 0L;
            int bit = 0;
            for (int y = 0; y < 8; y++) {
                for (int x = 0; x < 8; x++) {
                    int left = gray(scaled.getPixel(x, y));
                    int right = gray(scaled.getPixel(x + 1, y));
                    if (left > right) hash |= (1L << bit);
                    bit++;
                }
            }
            return hash;
        } catch (Exception e) {
            return null;
        } finally {
            if (scaled != null && scaled != bitmap) scaled.recycle();
            if (bitmap != null) bitmap.recycle();
        }
    }

    private static int gray(int color) {
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = color & 0xFF;
        return (r * 30 + g * 59 + b * 11) / 100;
    }

    private static String safe(String value, String fallback) {
        return value == null || value.trim().isEmpty() ? fallback : value;
    }
}
