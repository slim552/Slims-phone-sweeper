package com.slimproductions.phonesweep;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class LargeFilesActivity extends ReviewActivityBase {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private long threshold = 50L * 1024 * 1024;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setup("Large files", "Review the biggest accessible files on your phone. Nothing is selected automatically.", "Move selected files to trash");
        Button scan = Ui.button(this, "Scan files over 50 MB");
        scan.setOnClickListener(v -> runScan());
        root.addView(scan, 4);
        runScan();
    }

    private void runScan() {
        if (!PermissionHelper.hasMediaPermissions(this)) {
            status.setText("Media permission is required before scanning.");
            PermissionHelper.requestMediaPermissions(this);
            return;
        }
        results.removeAllViews();
        primaryAction.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(true);
        status.setText("Finding large files…");
        executor.submit(() -> {
            List<MediaItem> files = ScanUtils.queryLargeFiles(this, threshold);
            showItems(files, false, "No accessible files larger than 50 MB were found.");
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQUEST_MEDIA) {
            if (PermissionHelper.hasMediaPermissions(this)) runScan();
            else status.setText("Media access was not granted. You can grant it from Android app settings.");
        }
    }

    @Override
    protected void rerunAfterDelete() {
        runScan();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
