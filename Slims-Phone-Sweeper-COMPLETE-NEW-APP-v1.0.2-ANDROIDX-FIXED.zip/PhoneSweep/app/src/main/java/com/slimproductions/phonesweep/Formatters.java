package com.slimproductions.phonesweep;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public final class Formatters {
    private Formatters() {}

    public static String bytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        double value = bytes;
        String[] units = {"KB", "MB", "GB", "TB"};
        int index = -1;
        do {
            value /= 1024.0;
            index++;
        } while (value >= 1024 && index < units.length - 1);
        return String.format(Locale.US, value >= 10 ? "%.1f %s" : "%.2f %s", value, units[index]);
    }

    public static String date(long epochSeconds) {
        if (epochSeconds <= 0) return "Unknown date";
        return DateFormat.getDateInstance(DateFormat.MEDIUM).format(new Date(epochSeconds * 1000L));
    }
}
