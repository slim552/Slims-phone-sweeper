package com.slimproductions.phonesweep;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SimilarPhotoActivity extends ReviewActivityBase {
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setup("Similar photos", "Compare visual fingerprints to find burst shots, resized copies and near-identical pictures. Results are suggestions—review every image before moving anything to trash.", "Move selected photos to trash");
        Button scan = Ui.button(this, "Start similar-photo scan");
        scan.setOnClickListener(v -> runScan());
        root.addView(scan, 4);
    }

    private void runScan() {
        if (!PermissionHelper.hasImagePermission(this)) {
            status.setText("Photo permission is required before scanning.");
            PermissionHelper.requestMediaPermissions(this);
            return;
        }
        results.removeAllViews();
        primaryAction.setVisibility(View.GONE);
        progress.setVisibility(View.VISIBLE);
        progress.setIndeterminate(false);
        status.setText("Loading image thumbnails…");
        executor.submit(() -> {
            List<MediaItem> images = ScanUtils.queryImages(this);
            List<List<MediaItem>> groups = ScanUtils.findSimilarImages(this, images,
                    (done, total, message) -> showProgress(done, total, message));
            showGroups(groups, false, "No strongly similar photo groups were found.");
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PermissionHelper.REQUEST_MEDIA) {
            if (PermissionHelper.hasImagePermission(this)) runScan();
            else status.setText("Media access was not granted. You can grant it from Android app settings.");
        }
    }

    @Override
    protected void rerunAfterDelete() {
        runScan();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }
}
