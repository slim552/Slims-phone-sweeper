package com.slimproductions.phonesweep;

import android.content.ComponentName;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

public class OptimizeActivity extends BaseActivity {
    private TextView status;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = Ui.screen(this);
        root.addView(Ui.title(this, "Quick optimize"));
        root.addView(Ui.subtitle(this, "Clean Slims Phone Sweeper's own temporary cache, then open the safest system tools for storage, apps, battery and Samsung Device Care. Android does not allow ordinary apps to silently clear every other app's cache or force-stop the phone."));
        status = Ui.body(this, "Ready");
        root.addView(status);

        Button clear = Ui.button(this, "Clear Slims Phone Sweeper cache");
        clear.setOnClickListener(v -> clearOwnCache());
        root.addView(clear);

        Button deviceCare = Ui.button(this, "Open Samsung Device Care");
        deviceCare.setOnClickListener(v -> openSamsungDeviceCare());
        root.addView(deviceCare);

        Button storage = Ui.secondaryButton(this, "Open Android storage manager");
        storage.setOnClickListener(v -> openSettings(Settings.ACTION_INTERNAL_STORAGE_SETTINGS));
        root.addView(storage);

        Button apps = Ui.secondaryButton(this, "Review installed apps");
        apps.setOnClickListener(v -> openSettings(Settings.ACTION_MANAGE_APPLICATIONS_SETTINGS));
        root.addView(apps);

        Button battery = Ui.secondaryButton(this, "Open battery settings");
        battery.setOnClickListener(v -> openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS));
        root.addView(battery);

        setContentView(Ui.scrollScreen(this, root));
        if (getIntent().getBooleanExtra("auto_run", false)) clearOwnCache();
    }

    private void clearOwnCache() {
        long before = folderSize(getCacheDir());
        deleteChildren(getCacheDir());
        File external = getExternalCacheDir();
        if (external != null) {
            before += folderSize(external);
            deleteChildren(external);
        }
        status.setText("Cleared about " + Formatters.bytes(before) + " of Slims Phone Sweeper temporary data.");
    }

    private void openSamsungDeviceCare() {
        Intent[] attempts = new Intent[]{
                new Intent("com.samsung.android.sm.ACTION_SMART_MANAGER"),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool",
                        "com.samsung.android.sm.ui.cstyleboard.SmartManagerDashBoardActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool",
                        "com.samsung.android.sm.ui.dashboard.SmartManagerDashBoardActivity")),
                new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)
        };
        for (Intent intent : attempts) {
            try {
                if (intent.resolveActivity(getPackageManager()) != null) {
                    startActivity(intent);
                    return;
                }
            } catch (Exception ignored) {}
        }
        Toast.makeText(this, "Device Care was not found. Open Settings and search for Device care.", Toast.LENGTH_LONG).show();
    }

    private void openSettings(String action) {
        try {
            startActivity(new Intent(action));
        } catch (Exception e) {
            try {
                Intent fallback = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:" + getPackageName()));
                startActivity(fallback);
            } catch (Exception ignored) {}
        }
    }

    private static long folderSize(File file) {
        if (file == null || !file.exists()) return 0;
        if (file.isFile()) return file.length();
        long total = 0;
        File[] children = file.listFiles();
        if (children != null) for (File child : children) total += folderSize(child);
        return total;
    }

    private static void deleteChildren(File folder) {
        if (folder == null || !folder.exists()) return;
        File[] children = folder.listFiles();
        if (children == null) return;
        for (File child : children) {
            if (child.isDirectory()) deleteChildren(child);
            child.delete();
        }
    }
}
