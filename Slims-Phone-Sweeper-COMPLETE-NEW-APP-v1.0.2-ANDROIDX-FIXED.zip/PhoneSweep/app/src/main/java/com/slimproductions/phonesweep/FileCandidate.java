package com.slimproductions.phonesweep;

import java.io.File;

public final class FileCandidate {
    public final File file;
    public final String reason;
    public final boolean suggested;

    public FileCandidate(File file, String reason, boolean suggested) {
        this.file = file;
        this.reason = reason;
        this.suggested = suggested;
    }
}
