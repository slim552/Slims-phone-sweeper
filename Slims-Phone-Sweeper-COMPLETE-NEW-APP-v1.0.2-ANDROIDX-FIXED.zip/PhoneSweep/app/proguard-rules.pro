# Slims Phone Sweeper uses only Android platform APIs. No custom keep rules are required.
