@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"

where java >nul 2>nul
if errorlevel 1 (
  echo Java 17 or newer is required. Install Android Studio, then run this file again.
  pause
  exit /b 1
)

if "%ANDROID_HOME%"=="" set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
set "SDKMANAGER=%ANDROID_HOME%\cmdline-tools\latest\bin\sdkmanager.bat"

if not exist "%SDKMANAGER%" (
  echo Installing Android command-line tools...
  set "TOOLS_ZIP=%TEMP%\phonesweep-android-tools.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip' -OutFile '!TOOLS_ZIP!'"
  if errorlevel 1 goto :fail
  if exist "%TEMP%\phonesweep-cmdline" rmdir /s /q "%TEMP%\phonesweep-cmdline"
  mkdir "%TEMP%\phonesweep-cmdline"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '!TOOLS_ZIP!' '%TEMP%\phonesweep-cmdline'"
  mkdir "%ANDROID_HOME%\cmdline-tools" 2>nul
  if exist "%ANDROID_HOME%\cmdline-tools\latest" rmdir /s /q "%ANDROID_HOME%\cmdline-tools\latest"
  move "%TEMP%\phonesweep-cmdline\cmdline-tools" "%ANDROID_HOME%\cmdline-tools\latest" >nul
)

set "PATH=%ANDROID_HOME%\platform-tools;%ANDROID_HOME%\cmdline-tools\latest\bin;%PATH%"
(for /l %%i in (1,1,50) do @echo y) | "%SDKMANAGER%" --licenses >nul
call "%SDKMANAGER%" "platform-tools" "platforms;android-35" "build-tools;35.0.0"
if errorlevel 1 goto :fail

set "GRADLE_HOME=%USERPROFILE%\.phonesweep\gradle-8.9"
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Installing Gradle 8.9...
  set "GRADLE_ZIP=%TEMP%\phonesweep-gradle.zip"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.9-bin.zip' -OutFile '!GRADLE_ZIP!'"
  if errorlevel 1 goto :fail
  if exist "%USERPROFILE%\.phonesweep" rmdir /s /q "%USERPROFILE%\.phonesweep"
  mkdir "%USERPROFILE%\.phonesweep"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '!GRADLE_ZIP!' '%USERPROFILE%\.phonesweep'"
)

call "%GRADLE_HOME%\bin\gradle.bat" --no-daemon clean assembleDebug
if errorlevel 1 goto :fail
copy /y "app\build\outputs\apk\debug\app-debug.apk" "Slims-Phone-Sweeper-debug.apk" >nul
echo.
echo SUCCESS: Slims-Phone-Sweeper-debug.apk is ready in this folder.
pause
exit /b 0

:fail
echo.
echo Build failed. Open this project in Android Studio and choose Build APK.
pause
exit /b 1
