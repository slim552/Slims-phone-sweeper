#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

ANDROID_HOME="${ANDROID_HOME:-$HOME/Android/Sdk}"
export ANDROID_HOME
mkdir -p "$ANDROID_HOME/cmdline-tools"
SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"

if [[ ! -x "$SDKMANAGER" ]]; then
  echo "Installing Android command-line tools..."
  tmp="$(mktemp -d)"
  curl -L --fail -o "$tmp/tools.zip" "https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip"
  unzip -q "$tmp/tools.zip" -d "$tmp/unpacked"
  rm -rf "$ANDROID_HOME/cmdline-tools/latest"
  mv "$tmp/unpacked/cmdline-tools" "$ANDROID_HOME/cmdline-tools/latest"
fi

yes | "$SDKMANAGER" --licenses >/dev/null || true
"$SDKMANAGER" "platform-tools" "platforms;android-35" "build-tools;35.0.0"

GRADLE_HOME="$HOME/.phonesweep/gradle-8.9"
if [[ ! -x "$GRADLE_HOME/bin/gradle" ]]; then
  tmp="$(mktemp -d)"
  mkdir -p "$HOME/.phonesweep"
  curl -L --fail -o "$tmp/gradle.zip" "https://services.gradle.org/distributions/gradle-8.9-bin.zip"
  unzip -q "$tmp/gradle.zip" -d "$HOME/.phonesweep"
fi

"$GRADLE_HOME/bin/gradle" --no-daemon clean assembleDebug
cp app/build/outputs/apk/debug/app-debug.apk Slims-Phone-Sweeper-debug.apk
echo "SUCCESS: $(pwd)/Slims-Phone-Sweeper-debug.apk"
